/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define B1_Pin GPIO_PIN_13
#define B1_GPIO_Port GPIOC
#define VBUS_SENSE_Pin GPIO_PIN_3
#define VBUS_SENSE_GPIO_Port GPIOC
#define S1_STATUS_Pin GPIO_PIN_0
#define S1_STATUS_GPIO_Port GPIOA
#define S2_STATUS_Pin GPIO_PIN_1
#define S2_STATUS_GPIO_Port GPIOA
#define S3_STATUS_Pin GPIO_PIN_4
#define S3_STATUS_GPIO_Port GPIOA
#define S4_STATUS_Pin GPIO_PIN_5
#define S4_STATUS_GPIO_Port GPIOA
#define S5_STATUS_Pin GPIO_PIN_6
#define S5_STATUS_GPIO_Port GPIOA
#define S6_STATUS_Pin GPIO_PIN_7
#define S6_STATUS_GPIO_Port GPIOA
#define S15_STATUS_Pin GPIO_PIN_4
#define S15_STATUS_GPIO_Port GPIOC
#define S16_STATUS_Pin GPIO_PIN_5
#define S16_STATUS_GPIO_Port GPIOC
#define S7_STATUS_Pin GPIO_PIN_0
#define S7_STATUS_GPIO_Port GPIOB
#define S8_STATUS_Pin GPIO_PIN_1
#define S8_STATUS_GPIO_Port GPIOB
#define S42_STATUS_Pin GPIO_PIN_12
#define S42_STATUS_GPIO_Port GPIOF
#define S43_STATUS_Pin GPIO_PIN_13
#define S43_STATUS_GPIO_Port GPIOF
#define S44_STATUS_Pin GPIO_PIN_14
#define S44_STATUS_GPIO_Port GPIOF
#define S45_STATUS_Pin GPIO_PIN_15
#define S45_STATUS_GPIO_Port GPIOF
#define S46_STATUS_Pin GPIO_PIN_0
#define S46_STATUS_GPIO_Port GPIOG
#define S47_STATUS_Pin GPIO_PIN_1
#define S47_STATUS_GPIO_Port GPIOG
#define S33_STATUS_Pin GPIO_PIN_7
#define S33_STATUS_GPIO_Port GPIOE
#define S34_STATUS_Pin GPIO_PIN_8
#define S34_STATUS_GPIO_Port GPIOE
#define S35_STATUS_Pin GPIO_PIN_9
#define S35_STATUS_GPIO_Port GPIOE
#define S36_STATUS_Pin GPIO_PIN_10
#define S36_STATUS_GPIO_Port GPIOE
#define S37_STATUS_Pin GPIO_PIN_11
#define S37_STATUS_GPIO_Port GPIOE
#define S38_STATUS_Pin GPIO_PIN_12
#define S38_STATUS_GPIO_Port GPIOE
#define S39_STATUS_Pin GPIO_PIN_13
#define S39_STATUS_GPIO_Port GPIOE
#define S40_STATUS_Pin GPIO_PIN_14
#define S40_STATUS_GPIO_Port GPIOE
#define S41_STATUS_Pin GPIO_PIN_15
#define S41_STATUS_GPIO_Port GPIOE
#define S9_STATUS_Pin GPIO_PIN_10
#define S9_STATUS_GPIO_Port GPIOB
#define S10_STATUS_Pin GPIO_PIN_11
#define S10_STATUS_GPIO_Port GPIOB
#define S11_STATUS_Pin GPIO_PIN_12
#define S11_STATUS_GPIO_Port GPIOB
#define LD3_Pin GPIO_PIN_14
#define LD3_GPIO_Port GPIOB
#define S14_STATUS_Pin GPIO_PIN_10
#define S14_STATUS_GPIO_Port GPIOD
#define S12_STATUS_Pin GPIO_PIN_11
#define S12_STATUS_GPIO_Port GPIOD
#define S13_STATUS_Pin GPIO_PIN_12
#define S13_STATUS_GPIO_Port GPIOD
#define S31_STATUS_Pin GPIO_PIN_14
#define S31_STATUS_GPIO_Port GPIOD
#define S32_STATUS_Pin GPIO_PIN_15
#define S32_STATUS_GPIO_Port GPIOD
#define STLK_RX_Pin GPIO_PIN_7
#define STLK_RX_GPIO_Port GPIOG
#define STLK_TX_Pin GPIO_PIN_8
#define STLK_TX_GPIO_Port GPIOG
#define S17_STATUS_Pin GPIO_PIN_6
#define S17_STATUS_GPIO_Port GPIOC
#define S18_STATUS_Pin GPIO_PIN_7
#define S18_STATUS_GPIO_Port GPIOC
#define S19_STATUS_Pin GPIO_PIN_8
#define S19_STATUS_GPIO_Port GPIOC
#define S20_STATUS_Pin GPIO_PIN_9
#define S20_STATUS_GPIO_Port GPIOC
#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define S48_STATUS_Pin GPIO_PIN_15
#define S48_STATUS_GPIO_Port GPIOA
#define S21_STATUS_Pin GPIO_PIN_10
#define S21_STATUS_GPIO_Port GPIOC
#define S22_STATUS_Pin GPIO_PIN_11
#define S22_STATUS_GPIO_Port GPIOC
#define S23_STATUS_Pin GPIO_PIN_12
#define S23_STATUS_GPIO_Port GPIOC
#define S24_STATUS_Pin GPIO_PIN_0
#define S24_STATUS_GPIO_Port GPIOD
#define S25_STATUS_Pin GPIO_PIN_1
#define S25_STATUS_GPIO_Port GPIOD
#define S26_STATUS_Pin GPIO_PIN_3
#define S26_STATUS_GPIO_Port GPIOD
#define S27_STATUS_Pin GPIO_PIN_4
#define S27_STATUS_GPIO_Port GPIOD
#define S28_STATUS_Pin GPIO_PIN_5
#define S28_STATUS_GPIO_Port GPIOD
#define S29_STATUS_Pin GPIO_PIN_6
#define S29_STATUS_GPIO_Port GPIOD
#define S30_STATUS_Pin GPIO_PIN_7
#define S30_STATUS_GPIO_Port GPIOD
#define SWO_Pin GPIO_PIN_3
#define SWO_GPIO_Port GPIOB
#define LD2_Pin GPIO_PIN_7
#define LD2_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */
/*#define INPUT_PIN     0
//#define GPIO_PIN_0    1//INPUT_PIN+1
#define S2_STATUS_Pin  INPUT_PIN+2
#define S3_STATUS_Pin  INPUT_PIN+3
#define S4_STATUS_Pin  INPUT_PIN+4
#define S5_STATUS_Pin  INPUT_PIN+5
#define S6_STATUS_Pin  INPUT_PIN+6
#define S7_STATUS_Pin  INPUT_PIN+7
#define S8_STATUS_Pin  INPUT_PIN+8
#define S9_STATUS_Pin  INPUT_PIN+9
#define S10_STATUS_Pin INPUT_PIN+10
#define S11_STATUS_Pin INPUT_PIN+11
#define S12_STATUS_Pin INPUT_PIN+12
#define S13_STATUS_Pin INPUT_PIN+13
#define S14_STATUS_Pin INPUT_PIN+14
#define S15_STATUS_Pin INPUT_PIN+15
#define S16_STATUS_Pin INPUT_PIN+16
#define S17_STATUS_Pin INPUT_PIN+17
#define S18_STATUS_Pin INPUT_PIN+18
#define S19_STATUS_Pin INPUT_PIN+19
#define S20_STATUS_Pin INPUT_PIN+20
#define S21_STATUS_Pin INPUT_PIN+21
#define S22_STATUS_Pin INPUT_PIN+22
#define S23_STATUS_Pin INPUT_PIN+23
#define S24_STATUS_Pin INPUT_PIN+24
#define S25_STATUS_Pin INPUT_PIN+25
#define S26_STATUS_Pin INPUT_PIN+26
#define S27_STATUS_Pin INPUT_PIN+27
#define S28_STATUS_Pin INPUT_PIN+28
#define S29_STATUS_Pin INPUT_PIN+29
#define S30_STATUS_Pin INPUT_PIN+30
#define S31_STATUS_Pin INPUT_PIN+31
#define S32_STATUS_Pin INPUT_PIN+32
#define S33_STATUS_Pin INPUT_PIN+33
#define S34_STATUS_Pin INPUT_PIN+34
#define S35_STATUS_Pin INPUT_PIN+35
#define S36_STATUS_Pin INPUT_PIN+36
#define S37_STATUS_Pin INPUT_PIN+37
#define S38_STATUS_Pin INPUT_PIN+38
#define S39_STATUS_Pin INPUT_PIN+39
#define S40_STATUS_Pin INPUT_PIN+40
#define S41_STATUS_Pin INPUT_PIN+41
#define S42_STATUS_Pin INPUT_PIN+42
#define S43_STATUS_Pin INPUT_PIN+43
#define S44_STATUS_Pin INPUT_PIN+44
#define S45_STATUS_Pin INPUT_PIN+45
#define S46_STATUS_Pin INPUT_PIN+46
#define S47_STATUS_Pin INPUT_PIN+47
#define S48_STATUS_Pin INPUT_PIN+48





#define INPUT_PORT    0
//#define 1            GPIOA                        //INPUT_PORT+1
#define S2_STATUS_GPIO_Port  INPUT_PORT+2
#define S3_STATUS_GPIO_Port  INPUT_PORT+3
#define S4_STATUS_GPIO_Port  INPUT_PORT+4
#define S5_STATUS_GPIO_Port  INPUT_PORT+5
#define S6_STATUS_GPIO_Port  INPUT_PORT+6
#define S7_STATUS_GPIO_Port  INPUT_PORT+7
#define S8_STATUS_GPIO_Port  INPUT_PORT+8
#define S9_STATUS_GPIO_Port  INPUT_PORT+9
#define S10_STATUS_GPIO_Port INPUT_PORT+10
#define S11_STATUS_GPIO_Port INPUT_PORT+11
#define S12_STATUS_GPIO_Port INPUT_PORT+12
#define S13_STATUS_GPIO_Port INPUT_PORT+13
#define S14_STATUS_GPIO_Port INPUT_PORT+14
#define S15_STATUS_GPIO_Port INPUT_PORT+15
#define S16_STATUS_GPIO_Port INPUT_PORT+16
#define S17_STATUS_GPIO_Port INPUT_PORT+17
#define S18_STATUS_GPIO_Port INPUT_PORT+18
#define S19_STATUS_GPIO_Port INPUT_PORT+19
#define S20_STATUS_GPIO_Port INPUT_PORT+20
#define S21_STATUS_GPIO_Port INPUT_PORT+21
#define S22_STATUS_GPIO_Port INPUT_PORT+22
#define S23_STATUS_GPIO_Port INPUT_PORT+23
#define S24_STATUS_GPIO_Port INPUT_PORT+24
#define S25_STATUS_GPIO_Port INPUT_PORT+25
#define S26_STATUS_GPIO_Port INPUT_PORT+26
#define S27_STATUS_GPIO_Port INPUT_PORT+27
#define S28_STATUS_GPIO_Port INPUT_PORT+28
#define S29_STATUS_GPIO_Port INPUT_PORT+29
#define S30_STATUS_GPIO_Port INPUT_PORT+30
#define S31_STATUS_GPIO_Port INPUT_PORT+31
#define S32_STATUS_GPIO_Port INPUT_PORT+32
#define S33_STATUS_GPIO_Port INPUT_PORT+33
#define S34_STATUS_GPIO_Port INPUT_PORT+34
#define S35_STATUS_GPIO_Port INPUT_PORT+35
#define S36_STATUS_GPIO_Port INPUT_PORT+36
#define S37_STATUS_GPIO_Port INPUT_PORT+37
#define S38_STATUS_GPIO_Port INPUT_PORT+38
#define S39_STATUS_GPIO_Port INPUT_PORT+39
#define S40_STATUS_GPIO_Port INPUT_PORT+40
#define S41_STATUS_GPIO_Port INPUT_PORT+41
#define S42_STATUS_GPIO_Port INPUT_PORT+42
#define S43_STATUS_GPIO_Port INPUT_PORT+43
#define S44_STATUS_GPIO_Port INPUT_PORT+44
#define S45_STATUS_GPIO_Port INPUT_PORT+45
#define S46_STATUS_GPIO_Port INPUT_PORT+46
#define S47_STATUS_GPIO_Port INPUT_PORT+47
#define S48_STATUS_GPIO_Port INPUT_PORT+48*/


/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
